<?php  
include('Connection/connection.php');
include('Header/header_D.php');
  // CREATE CONNECTION
  $conn = new mysqli($servername,$username, $password, $databasename);
  
  // GET CONNECTION ERRORS
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }
   if(isset($_GET['product_id'])){
 	$prod_id=$_GET['product_id'];
  // SQL QUERY
  $query = "SELECT * FROM `Products` WHERE item_id=$prod_id";
  
  // FETCHING DATA FROM DATABASE
  $result = $conn->query($query);
  
    if ($result->num_rows > 0) 
    {
        // OUTPUT DATA OF EACH ROW
        while($row = $result->fetch_assoc())
{
             $pro_id=$row['item_id'];
             $pro_nam=$row['item_name'];
             $pro_pri=$row['item_price'];
             $pro_des=$row['item_description'];
             $pro_img=$row['item_image'];
             $pro_q=$row['item_quantity'];
            echo" <div class='row'>
  <div class='column'>
  <div class='card'>
    <img src='Images/$pro_img 'style='width:100%'>
  <h6><b>$pro_nam</b></h6>
  <p class='price'>₹$pro_pri</p>
   <p class='Discription:'>$pro_des</p>
    In Stock: <p class='Quantity:'>$pro_q</p>
   <p><a href='addtocart.php?id=$pro_id&qu=$pro_q'class='w3-button w3-hover-red w3-blue'> Add to <i class='fa fa-shopping-cart'></i></button></a></p>
        </form>
    </div>
    </div>
  </div>";
             }
           }
        }
             ?>
<html>
<head>
<link rel='stylesheet' href='Stylesheets/card.css' type='text/css' media='all' />
</head>
</html>
</body>
 </html>