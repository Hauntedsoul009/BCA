<!DOCTYPE html>
<html lang="en">
<head>
	<title>Home</title>
<meta charset='UTF-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.css'>
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Lato'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>
<style>
body {font-family: 'Lato', sans-serif}
.mySlides {display: none}
</style>
</head>
<body>
	<?php 
	session_start();
include('Connection/connection.php');
$servername = "localhost";
  $username = "root";
  $password = "";
  $databasename = "Project";
  // CREATE CONNECTION
  $conn = new mysqli($servername,$username, $password, $databasename);
  
  // GET CONNECTION ERRORS
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }
  if(isset($_GET['uid'])){
 	$uid=$_GET['uid'];
 }
  $_SESSION['uid'] =$uid ;
  $query = "SELECT * FROM `user` WHERE userid=$uid ;";
  
  // FETCHING DATA FROM DATABASE
  $result = $conn->query($query);
  
    if ($result->num_rows > 0) 
    {
        // OUTPUT DATA OF EACH ROW
        while($row = $result->fetch_assoc())
{
         
             $_SESSION['na']=$row['username'];
              $_SESSION['ad']=$row['useraddress'];
             }
            }
            ?>
<!-- Navbar -->
<b><p>html lang="en">
<head>
<title> <i class='fa fa-home' aria-hidden='true'></i></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {font-family: "Lato", sans-serif}
.mySlides {display: none}
</style>
</head>
<!-- Navbar -->
<div class="w3-top">
  <b><div class="w3-bar w3-blue w3-card">
    <a class="w3-bar-item w3-button w3-hover-red w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onClick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="Category.php?cat_id=2" class="w3-bar-item w3-button w3-hover-red w3-padding-large w3-hide-small">HEALTH CARE DEVICES</a>
	 <div class="w3-dropdown-hover w3-hide-small">
      <button class="w3-padding-large w3-button w3-hover-red" title="More">MEDICINES<i class="fa fa-caret-down"></i></button>     
      <div class="w3-dropdown-content w3-bar-block w3-card-4">
        <a href="Category.php?cat_id=3" class="w3-bar-item w3-button w3-hover-red">Personal Care</a>
        <a href="Category.php?cat_id=4" class="w3-bar-item w3-button w3-hover-red ">Vitamin Supplements</a>
      </div>
    </div>
    <a href="Category.php?cat_id=1" class="w3-bar-item w3-button w3-hover-red w3-padding-large w3-hide-small">COVID ESSENTIALS</a>
     <div class="w3-dropdown-hover w3-hide-small ">
      <button class="w3-padding-large w3-button w3-hover-red" title="More"><i class="fa fa-user-circle"></i><i class="fa fa-caret-down"></i></button>     
      <div class="w3-dropdown-content w3-bar-block w3-card-4">
      	<?php echo"
        <a href='Userinfo.php?uid=$uid' class='w3-bar-item w3-button w3-hover-red '>User Info</a>
        <a href='em_cart.php' class='w3-bar-item w3-button w3-hover-red'>Logout</a>";
        ?>
      </div>
    </div>   
    <?php echo"
    <a href='cart.php?uid=$id' class='w3-padding-large w3-hover-red  w3-right'><i class='fa fa-shopping-cart' aria-hidden='true'></i></a>";
    ?>
  </div>  
</div><br><br></b>
<!-- Navbar on small screens (remove the onclick attribute if you want the navbar to always show on top of the content when clicking on the links) -->
<div id="navDemo" class="w3-bar-block w3-black w3-hide w3-hide-large w3-hide-medium w3-top" style="margin-top:46px">
  <a href="#band" class="w3-bar-item w3-button w3-padding-large" onClick="myFunction()">Home</a>
  <a href="#tour" class="w3-bar-item w3-button w3-padding-large" onClick="myFunction()">TOUR</a>
  <a href="#contact" class="w3-bar-item w3-button w3-padding-large" onClick="myFunction()">CONTACT US</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large" onClick="myFunction()">MERCH</a>
</div>

<!-- Page content -->
<div class="w3-content" style="max-width:2000px;margin-top:46px">

  <!-- Automatic Slideshow Images -->
  <div class="mySlides w3-display-container w3-center">
    <img src="Images/prg1.jpeg" style="width:100%">
    <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
      <h2><B>WELCOME TO OUR WEBSITE</B></h2>
      <p><b>The art of medicine consists of amusing the patient while nature cures the disease.
</b></p>   
    </div>
  </div>
  <div class="mySlides w3-display-container w3-center">
    <img src="Images/pharma.jpg" style="width:100%">
    <div class="w3-display-bottommiddle w3-container w3-text-black w3-padding-32 w3-hide-small">
      <h2><B>HAPPINESS</B></h2>
      <p><b>We are no longer happy so soon as we wish to be happier.</b></p> 
    </div>
  </div>
  <div class="mySlides w3-display-container w3-center">
    <img src="Images/epharmacy-social.jpg" style="width:100%">
    <div class="w3-display-bottommiddle w3-container w3-text-orange w3-padding-32 w3-hide-small">
      <h2><B>FREE DELIVERY</B></h2>
      <p ><b>Book your orders and get free deliveryy!!..</b></p>    
    </div>
  </div>

  <!-- The Band Section -->
  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px" id="band">
    <h2 class="w3-wide">Why Us</h2>
    <p class="w3-opacity"><i><u>YOUR HEALTH IS OUR HAPPINESS</u></i></p>
    <p class="w3-justify"><b>1
.Convenient:</b> Online pharmacy serves a convenient way of buying medicine for old age, physically challenged and working professionals, due to the difficulty for them to go local medical shop.<br>

<b>2
.Time-saving:</b> Online pharmacy saves your time and efforts, in just a few minutes you can head over the E-pharmacy websites and buy any prescription medicine as per your need. It saves the time that you can spend in traveling to your local pharmacy shop and waiting in line for medicine.<br>

<b>3
.Anytime anywhere:</b> You can place your order anytime from anywhere as there is no issue of pharmacy closing down. 24*7 online customer supports are there to solve your queries regarding medicines.</p>
    <div class="w3-row w3-padding-32">
      <div class="w3-third">
        <img src="Images/delivery.jpeg" class="w3-round w3-margin-bottom" alt="evion-400mg-strip-of-10-capsules-2" style="width:100%">
	</div>
      <div class="w3-third">
        <img src="Images/license.jpeg" class="w3-round w3-margin-bottom" alt="Random Name" style="width:100%">
      </div>
      <div class="w3-third">
        <img src="Images/support.jpeg" class="w3-round w3-margin-bottom" alt="Random Name" style="width:85%">
      </div>
    </div>
  </div>

  <!-- The Tour Section -->
  <div class="w3-teal" id="Top Products">
    <div class="w3-container w3-content w3-padding-64" style="max-width:800px">
      <h2 class="w3-wide w3-center ">Upcoming Products</h2>
      <div class="w3-row-padding w3-padding-32" style="margin:0 -16px">
        <div class="w3-third w3-margin-bottom">
          <img src="Images/evion.jpeg" class="w3-round w3-margin-bottom" alt="evion-400mg-strip-of-10-capsules-2"style="width:250px""height:150px">
          <div class="w3-container w3-white">
            <p><b>Evion 400mg</b>(Strip of 10 Capsules)</p>
          </div>
        </div>
        <div class="w3-third w3-margin-bottom">
		  <img src="Images/supradyn.jpeg" class="w3-round w3-margin-bottom" alt="Random Name"style="width:250px""height:150px">
          <div class="w3-container w3-white">
            <p><b>Supradyn</b>(Daily Multivitamin tablets 15)</p>
          </div>
        </div>
        <div class="w3-third w3-margin-bottom">
           <img src="Images/neurobion.jpeg" class="w3-round w3-margin-bottom" alt="Random Name" style="width:101%">&nbsp;
          <div class="w3-container w3-white"><br>
            <p><b>Neurobion Forte</b>(Tablet-30)</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  
  <!-- The Contact Section -->
  <div class="w3-container w3-content w3-padding-64" style="max-width:800px" id="contact">
    <h2 class="w3-wide w3-center">CONTACT</h2>
    <p class="w3-opacity w3-center"><i>Drop your concerns</i></p>
    <div class="w3-row w3-padding-32">
      <div class="w3-col m6 w3-large w3-margin-bottom">
        <i class="fa fa-map-marker" style="width:30px"></i> Kerala, INDIA<br>
        <i class="fa fa-phone" style="width:30px"></i> Phone: +91 9695491413<br>
        <i class="fa fa-envelope" style="width:30px"> </i> Email: PHARMA@Gmail.com<br>
      </div>
      <div class="w3-col m6">
        <form action="/action_page.php" target="_blank">
          <div class="w3-row-padding" style="margin:0 -16px 8px -16px">
            <div class="w3-half">
              <input class="w3-input w3-border" type="text" placeholder="Name" required name="Name">
            </div>
            <div class="w3-half">
              <input class="w3-input w3-border" type="text" placeholder="Email" required name="Email">
            </div>
          </div>
          <input class="w3-input w3-border" type="text" placeholder="Message" required name="Message">
          <button class="w3-button w3-black w3-section w3-right" type="submit">SEND</button>
        </form>
      </div>
    </div>
  </div>
  
<!-- End Page Content -->
</div>

<!-- Image of location/map -->
<img src="Images/medicine.jpg" class="w3-image w3-greyscale-min" style="width:100%">

<!-- Footer -->
<footer class="w3-container w3-padding-64 w3-center w3-opacity w3-light-grey w3-xlarge">
  <i class="fa fa-facebook-official w3-hover-opacity"></i>
  <i class="fa fa-instagram w3-hover-opacity"></i>
  <i class="fa fa-snapchat w3-hover-opacity"></i>
  <i class="fa fa-pinterest-p w3-hover-opacity"></i>
  <i class="fa fa-twitter w3-hover-opacity"></i>
  <i class="fa fa-linkedin w3-hover-opacity"></i>
  
</footer>

<script>
// Automatic Slideshow - change image every 4 seconds
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 4000);    
}

// Used to toggle the menu on small screens when clicking on the menu button
function myFunction() {
  var x = document.getElementById("navDemo");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else { 
    x.className = x.className.replace(" w3-show", "");
  }
}

// When the user clicks anywhere outside of the modal, close it
var modal = document.getElementById('ticketModal');
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>

</body>
</html>
