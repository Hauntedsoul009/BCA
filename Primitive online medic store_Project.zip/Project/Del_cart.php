<?php
include('Connection/connection.php');
if(isset($_GET['id'])){
 	$prod_id=$_GET['id'];
 }
$sql = "DELETE FROM `Cart` WHERE  item_id=$prod_id";
if (mysqli_query($conn, $sql)) {
     echo "Deleted successfully";
} else {
     echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
header('location:cart.php');
mysqli_close($conn);
?>