<?php
include('Connection/connection.php');

if(isset($_GET['uid'])){
 	$uid=$_GET['uid'];
 }
 if(isset($_GET['tp'])){
 	$tp=$_GET['tp'];
 }
  // SQL QUERY
  $query = "INSERT INTO `orders` SELECT*FROM `Cart` JOIN `user` WHERE userid=$uid";
       if (mysqli_query($conn, $query)) {
     echo "New record created successfully";
} else {
     echo "Error: " . $query . "<br>" . mysqli_error($conn);
}
              
              
            
                //header('location:update_pro.php');
                ?>
                	<html>
                	<body>
                <?php echo "<script>
                	
alert('Order Placed Pls Sing out if you are leaving');
window.location.href='Home.php?uid=$uid';

</script>";
?>
</body>
</html>