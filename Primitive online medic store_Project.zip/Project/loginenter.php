<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Inserting details</title>
</head>
 
<body>
<?php
session_start();
include('Connection/connection.php');
  $servername = "localhost";
  $username = "root";
  $password = "";
  $databasename = "Project";
  
  // CREATE CONNECTION
  $conn = new mysqli($servername,$username, $password, $databasename);
  
  // GET CONNECTION ERRORS
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }
$i=$_POST['userid'];
$un=$_POST['username'];
$e=$_POST['usermail'];
$p=$_POST['userpassword'];
$a=$_POST['useraddress'];
$sql = "INSERT INTO `user` (`userid`, `username`, `usermail`, `userpassword`, `useraddress`) VALUES ('$i','$un','$e','$p','$a')";
if ($conn->query($sql) === TRUE)
{
echo '<script type="text/javascript">
 alert("registered sucessfully")
 </script>';
header("Location:Home.php?uid=$i");
}
else
{
 echo '<script type="text/javascript">
 alert("invalid input")
 </script>';
}
?>
<br/>
</body>
</html>
>
