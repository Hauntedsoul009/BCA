<html>
<?php
session_start();
include_once 'admin.css';
include_once 'admin_nav.php';
include('C:\wamp\www\Project\Connection\conn.php');
$sql_query=mysql_query("select * from user");
?>	
<br /><br />
<label><h2><u>User List</u></h2></label><br /><br />
<?php
echo"<table border='1'>";
echo"<tr>
<th>Id</th>
<th>Name</th>
<th>Email</th>
<th>Address</th>
<th>Password</th>
</tr>";
while($row=mysql_fetch_array($sql_query))
{
echo"<tr>
<td>".$row['userid']."</td>
<td>".$row['username']."</td>
<td>".$row['usermail']."</td>
<td>".$row['useraddress']."</td>
<td>".$row['userpassword']."</td>
<td><a href='update_user.php?userid=".$row['userid']."'>Edit/<br>Delete</a></td>
</tr>";
}
?>
</table>
  <br />
<label>
<a href='add_user.php'>
<input type="submit" name="Add"  class="w3-button w3-red" value="Add user" />
</a>
</label>
</form>
</section>
<br />
<br />
</div>
</body>
</html>

 

 
