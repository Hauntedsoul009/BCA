<html>
<?php
session_start();
include_once 'admin.css';
include_once 'admin_nav.php';
include('C:\wamp\www\Project\Connection\conn.php');
$sql_query=mysql_query("select * from products");
?>	
<br /><br />
<label><h2><u>Product List</u></h2></label><br /><br />
<?php
echo"<table border='1'>";
echo"<tr>
<th>Id</th>
<th>Image</th>
<th>Name</th>
<th>Price</th>
<th>Description</th>
<th>Quantity</th>
</tr>";
while($row=mysql_fetch_array($sql_query))
{
echo"<tr>
<td>".$row['item_id']."</td>
<td>".$row['item_image']."</td>
<td>".$row['item_name']."</td>
<td>".$row['item_price']."</td>
<td>".$row['item_description']."</td>
<td>".$row['item_quantity']."</td>
<td><a href='update_product.php?item_id=".$row['item_id']."'>Edit/<br>Delete</a></td>
</tr>";
}
?>
</table>
  <br />
<label>
<a href='add_product.php'>
<input type="submit" name="Add"  class="w3-button w3-red" value="Add user" />
</a>
</label>
</form>
</section>
<br />
<br />
</div>
</body>
</html>

 

 
