<html>
<head>
<title>Login</title>
</head>
<body>
<?php
session_start();
include("C:\wamp\www\Project\Connection\conn.php");
$e=$_POST['email'];
$p=$_POST['password'];
$query="select *from project.admin where Email='$e' and Password='$p'";
$sql=mysql_query($query);
$s=mysql_fetch_array($sql);
  if(!$s)
  {
    echo '<script type="text/javascript">
    alert("Worong password or email")
    </script>';
  }
 else{
     echo '<script type="text/javascript">
 alert("Successfully logged in")
 </script>';
 header("Location:adminpage.php");
 }
?>