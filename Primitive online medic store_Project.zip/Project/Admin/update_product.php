<html>
<head>
<?php
session_start();
include_once 'admin.css';
include_once 'admin_nav.php';
include('C:\wamp\www\Project\Connection\conn.php');
$id=$_GET['item_id'];
$qry= "select * from products where item_id='$id'";
$result=mysql_query($qry);
while($row=mysql_fetch_array($result))
{

?>
<form id="form1" name="form1" method="POST" >

<p>
<label>Item id
<input type="text" name="item_id" id="item_id" value="<?php echo $row[0];?>" />
</label>
</p><br />
  <p>
  <label>Image
  <input type="text" name="item_image" id="item_image" value="<?php echo $row[1];?>" />
  </label>
  </p><br />
  <p><label>Name
  <input type="text" name="item_name" id="item_name" value="<?php echo $row[2];?>" />
  </label>
  </p><br />
  <p>
  <label>Price
  <input type="text" name="item_price" id="item_price" value="<?php echo $row[3];?>" />
  </label>
  </p><br />
  <p>
  <label>Description 
  <input type="text" name="item_description" id="item_description" value="<?php echo $row[4];?>" />
  </label>
  <label>Quantity 
  <input type="text" name="item_quantity" id="item_quantity" value="<?php echo $row[5];?>" />
  </label>
  </p><br />
  
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <label>
  <input type="submit" class="w3-button w3-red" name="update" value="Edit" id="update"/>
  </label>&nbsp;&nbsp;&nbsp;
  <label>
  <input type="submit" class="w3-button w3-red" name="delete" value="Delete" id="delete"/>
  </label>
  </form>
<?php
}
?>
</div>
<?php
include("C:\wamp\www\Project\Connection\conn.php");
if(isset($_POST["update"]))
{
$i=$_POST['item_id'];
$n=$_POST['item_image'];
$m=$_POST['item_name'];
$d=$_POST['item_price'];
$w=$_POST['item_description'];
$q=$_POST['item_quantity'];
$sqlupdate="update products set item_id='$i',item_image='$n',item_name='$m',item_price='$d',item_description='$w',item_quantity='$q' where item_id=$id";
if(mysql_query($sqlupdate)==true)
{
echo "<br>";
echo '<script type="text/javascript">';
echo 'alert("Updated Successfully")';
echo '</script>';

}
else
{
echo "<br>";
echo '<script type="text/javascript">';
echo 'alert("Updation failed!!")';
echo '</script>';
}
}
else
{
if(isset($_POST['delete']))
{
$sqldelete="delete from products where item_id=$id";
if(mysql_query($sqldelete)==true)
{
echo "<br>";
echo '<script type="text/javascript">';
echo 'alert("Deleted Successfully")';
echo '</script>';
}
else
{
echo "<br>";
echo '<script type="text/javascript">';
echo 'alert("Deletion failed!!")';
echo '</script>';
}
}
}
?>
</body>
</html>
