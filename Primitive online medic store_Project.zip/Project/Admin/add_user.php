<html>
<?php
session_start();
include_once 'admin.css';
include_once 'admin_nav.php';
include('C:\wamp\www\Project\Connection\conn.php');
?>
<body>
<form id="form1" name="form1" method="POST" >

<p>
<label>User id
<input type="text" name="userid" id="userid" />
</label>
</p><br />
  <p>
  <label>Name
  <input type="text" name="username" id="username" />
  </label>
  </p><br />
  <p><label>Email
  <input type="text" name="usermail" id="usermail"/>
  </label>
  </p><br />
  <p>
  <label>Address
  <input type="text" name="useraddress" id="useraddress"/>
  </label>
  </p><br />
  <p>
  <label>Password 
  <input type="text" name="userpassword" id="userpassword"/>
  </label>
  </p><br />
  
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <label>
  <input type="submit" class="w3-button w3-red" name="update" value="Add" id="update"/>
  </label>&nbsp;&nbsp;&nbsp;
  
  </form>
<?php

?>
</div>
<?php
include("C:\wamp\www\Project\Connection\conn.php");
if(isset($_POST["update"]))
{
$id=$_POST['userid'];
$n=$_POST['username'];
$m=$_POST['usermail'];
$d=$_POST['useraddress'];
$w=$_POST['userpassword'];
$sqlupdate="INSERT INTO user (`userid`,`username`,`usermail`,`useraddress`,`userpassword`) 
VALUES ('$id','$n','$m','$d','$w')";
if(mysql_query($sqlupdate)==true)
{
echo "<br>";
echo '<script type="text/javascript">';
echo 'alert("User added Successfully")';
echo '</script>';
}
else
{
echo "<br>";
echo '<script type="text/javascript">';
echo 'alert("failed!!")';
echo '</script>';
}
}

?>
</body>
</html>