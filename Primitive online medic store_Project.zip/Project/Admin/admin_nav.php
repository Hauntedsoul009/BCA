<html>
<body>
<body background="../assets/images/img11.jpg">
<div class="w3-bar w3-white w3-large">
<a href="adminpage.php" class="w3-bar-item w3-button w3-red w3-mobile">Home</a>
<a href="product.php" class="w3-bar-item w3-button w3-mobile">Product</a>
<a href="adminLogin.php" class="w3-bar-item w3-button w3-right w3-light-grey w3-mobile">Logout</a>
</body>
</html>