<?php
$servername = "localhost";
  $username = "root";
  $password = "";
  $databasename = "Project";
  
  // CREATE CONNECTION
  $conn = new mysqli($servername,$username, $password, $databasename);
  
  // GET CONNECTION ERRORS
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }
if(isset($_GET['item_id'])){
 	$i=$_GET['item_id'];
 }
 if(isset($_GET['item_image'])){
 	$g=$_GET['item_image'];
 }if(isset($_GET['item_name'])){
 	$n=$_GET['item_name'];
 }if(isset($_GET['item_price'])){
 	$p=$_GET['item_price'];
 }if(isset($_GET['item_description'])){
 	$d=$_GET['item_description'];
 }if(isset($_GET['item_quantity'])){
 	$q=$_GET['item_quantity'];
 }if(isset($_GET['itc_id'])){
 	$c=$_GET['itc_id'];
 }
 $sql = "INSERT INTO `Products` (`item_id`, `item_image`, `item_name`, `item_price`, `item_description`, `item_quantity`, `itc_id`) VALUES ('$i','$g','$n','$p','$d','$q','$c')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
header("Location:product.php");
$conn->close();
?>