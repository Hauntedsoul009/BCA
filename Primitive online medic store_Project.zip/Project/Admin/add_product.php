<html>
<body>
<?php
session_start();
include('admin.css');
include_once ('admin_nav.php');
include('C:\wamp\www\Project\Connection\connection.php');
echo"<form action='addtoproduct.php' method='get' >
<p>
<label>Item id
<input type='text' name='item_id' id='item_id'/>
</label>
</p><br />
  <p>
  <label>Image
  <input type='file' name='item_image' id='item_image'/>
  </label>
  </p><br />
  <p><label>Name
  <input type='text' name='item_name' id='item_name'/>
  </label>
  </p><br />
  <p>
  <label>Price
  <input type='text' name='item_price' id='item_price'/>
  </label>
  </p><br />
  <p>
  <label>Description 
  <input type='text' name='item_description' id='item_description'/>
  </label>
  <label>Quantity 
  <input type='text' name='item_quantity' id='item_quantity'/>
  </label>
  <label>Catagory Id 
  <input type='text' name='itc_id' id='itc_id' />
  </label>
  </p><br />
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <label>
  <input type='submit' class='w3-button w3-red' name='update' value='Add'/>
  </label>&nbsp;&nbsp;&nbsp;
  </form>";
  ?>
</body>
</html>