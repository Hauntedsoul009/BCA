<html>
<head>
<?php
session_start();
include_once 'admin.css';
include_once 'admin_nav.php';
include('C:\wamp\www\Project\Connection\conn.php');
$id=$_GET['userid'];
$qry= "select * from user where userid='$id'";
$result=mysql_query($qry);
while($row=mysql_fetch_array($result))
{

?>
<form id="form1" name="form1" method="POST" >

<p>
<label>User id
<input type="text" name="userid" id="userid" value="<?php echo $row[0];?>" />
</label>
</p><br />
  <p>
  <label>Name
  <input type="text" name="username" id="username" value="<?php echo $row[1];?>" />
  </label>
  </p><br />
  <p><label>Email
  <input type="text" name="usermail" id="usermail" value="<?php echo $row[2];?>" />
  </label>
  </p><br />
  <p>
  <label>Address
  <input type="text" name="useraddress" id="useraddress" value="<?php echo $row[3];?>" />
  </label>
  </p><br />
  <p>
  <label>Password 
  <input type="text" name="userpassword" id="userpassword" value="<?php echo $row[4];?>" />
  </label>
  </p><br />
  
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <label>
  <input type="submit" class="w3-button w3-red" name="update" value="Edit" id="update"/>
  </label>&nbsp;&nbsp;&nbsp;
  <label>
  <input type="submit" class="w3-button w3-red" name="delete" value="Delete" id="delete"/>
  </label>
  </form>
<?php
}
?>
</div>
<?php
include("C:\wamp\www\Project\Connection\conn.php");
if(isset($_POST["update"]))
{
$i=$_POST['userid'];
$n=$_POST['username'];
$m=$_POST['usermail'];
$d=$_POST['useraddress'];
$w=$_POST['userpassword'];
$sqlupdate="update user set userid='$i',username='$n',usermail='$m',useraddress='$d',userpassword='$w' where userid=$id";
if(mysql_query($sqlupdate)==true)
{
echo "<br>";
echo '<script type="text/javascript">';
echo 'alert("Updated Successfully")';
echo '</script>';

}
else
{
echo "<br>";
echo '<script type="text/javascript">';
echo 'alert("Updation failed!!")';
echo '</script>';
}
}
else
{
if(isset($_POST['delete']))
{
$sqldelete="delete from user where userid=$id";
if(mysql_query($sqldelete)==true)
{
echo "<br>";
echo '<script type="text/javascript">';
echo 'alert("Deleted Successfully")';
echo '</script>';

}
else
{
echo "<br>";
echo '<script type="text/javascript">';
echo 'alert("Deletion failed!!")';
echo '</script>';
}
}
}
?>
</body>
</html>
