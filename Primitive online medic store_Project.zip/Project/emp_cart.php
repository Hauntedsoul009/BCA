<?php
session_start();
include('Connection/connection.php');
$prod_id=$_SESSION["p_id"];
$sql = "DELETE FROM `Cart` WHERE item_id=$prod_id";
if (mysqli_query($conn, $sql)) {
 header("Location:Details.php?product_id=$prod_id");
} else {
     echo "Error: " . $sql . "<br>" . mysqli_error($conn);
     }
mysqli_close($conn);
?>