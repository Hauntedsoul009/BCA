<?php
session_start();
if(isset($_GET['id'])){
 	$prod_id=$_GET['id'];
 $_SESSION['p_id']=$prod_id;
 }
 ?>	
<script>               
alert('Required Quantity sould lie within stock limit.check your input!!');
window.location.href="emp_cart.php";
</script>
