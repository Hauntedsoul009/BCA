<?php  
session_start();
include('Connection/connection.php');
include('Header/header_C.php');
  // CREATE CONNECTION
  $conn = new mysqli($servername,$username, $password, $databasename);
  
  // GET CONNECTION ERRORS
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }
  // SQL QUERY
  $query = "SELECT * FROM `Cart`";
  
  // FETCHING DATA FROM DATABASE
  $result = $conn->query($query);
  
    if ($result->num_rows > 0) 
    {
        // OUTPUT DATA OF EACH ROW
        while($row = $result->fetch_assoc())
{
             $pro_id=$row['item_id'];
             $pro_nam=$row['item_name'];
             $pro_pri=$row['item_price'];
             $pro_img=$row['item_image'];
             $pro_q=$row['item_quantity'];
             $pro_des=$row['item_description'];
             $tp=$pro_pri*$pro_q;
            $uid= $_SESSION["uid"] ;
            echo" <div class='row'>
  <div class='column'>
  <div class='card'>
    <img src='Images/$pro_img 'style='width:100%'>
  <h6><b>$pro_nam</b></h6>
  Quantity<p class='Quantity'>$pro_q </p>
  User_id: <p class='id'>$uid</p>
    <p class='price'>Price:₹$pro_pri</p>
  <p class='price'>Total price:₹$tp</p>
   <p><a href='Del_cart.php?id=$pro_id' class='w3-button w3-hover-red w3-blue'> REMOVE <i class='fa fa-trash'></i></a></p>
        </form>
    </div>
    </div>
  </div>
";
             }
             
           }
        else echo"<h1 style='color:red' align='center'><b>Your Cart is empty!!😓</h1></b>";
             ?>
<html>
<head>
<link rel='stylesheet' href='Stylesheets/card.css' type='text/css' media='all' />
<?php
$query = "SELECT SUM(item_price*item_quantity) AS total_price FROM `Cart` ";
  
  // FETCHING DATA FROM DATABASE
  $result = $conn->query($query);
  if ($result->num_rows > 0) 
    {
        // OUTPUT DATA OF EACH ROW
        while($row = $result->fetch_assoc())
{
               $tot=$row['total_price'];
                 
               }
};
               ?>
               	
               	<?php echo
"<p align='center'><b>Cart Sub Total'Rs.$tot</b></p>
   <p align='center' ><a href='invoice.php?tp=$tot&uid=$uid'class='w3-button w3-hover-red w3-blue'> Proceed to buy<i class='fa fa-buy'></i></a></p>";
   ?>
</head>
</html>