<?php
session_start();
include('Header/header_U.php');
include('Connection/connection.php');

if(isset($_GET['uid'])){
 	$uid=$_GET['uid'];
 }
 $uid=$_SESSION["uid"];
 
  // SQL QUERY
  $query = "SELECT * FROM `user` WHERE userid=$uid";
  // FETCHING DATA FROM DATABASE
  $result = $conn->query($query);
  
    if ($result->num_rows > 0) 
    {
        // OUTPUT DATA OF EACH ROW
        while($row = $result->fetch_assoc())
{
            
            
             $i=$row['userid'];
             $n=$row['username'];
             $e=$row['usermail'];
             $a=$row['useraddress'];
            echo"<div class='row'>
   <p class='Name'>Name:<h3>$n</h3></p>
   <p class='id:'><b>User ID:$i</b></p>
   <p class='email'>$e</p>
   <p class='address'><b>Address:$a</p>";
            }
            }
            $_SESDION['name']=$n;
            $_SESDION['mail']=$e;
            $_SESDION['address']=$a;
            ?>
            	<h1 color:"Green">Your Order History😃:</h1>
            	<?php
session_start();
include('Connection/connection.php');

if(isset($_GET['uid'])){
 	$uid=$_GET['uid'];
 }
  // SQL QUERY
  $query = "SELECT * FROM `orders` WHERE userid=$uid";
  // FETCHING DATA FROM DATABASE
  $result = $conn->query($query);
  
    if ($result->num_rows > 0) 
    {
        // OUTPUT DATA OF EACH ROW
        while($row = $result->fetch_assoc())
{
            
            
             $o=$row['orderid'];
             $itn=$row['item_name'];
             $q=$row['item_quantity'];
             $ts=$row['total_spend'];
             $im=$row['item_image'];
             $p=$row['item_price'];
            echo"<div class='row'>
            	<div class='column'>
  <div class='card'>
  <img src='Images/$im 'style='width:100%'></img>
   <p class='Name'>item:<h3>$itn</h3></p>
      <p class='quantity:'>Price:$p</p>
   <p class='quantity:'>Quantity:$q</p>
   </div>
   </div>";
            }
            }else echo"<h1 style='color:red' align='center'><b>Your haven't ordered anything yet!!😞 �</h1></b>";
            
            ?>
            <html>
<head>
	<link rel='stylesheet' href='Stylesheets/card.css' type='text/css' media='all' />
</head>
</html>
            