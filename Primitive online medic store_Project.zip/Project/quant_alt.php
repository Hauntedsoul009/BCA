<?php
include('Connection/connection.php');
 $q=$_GET['quant'];
 $prod_id=$_GET['id'];
 $qu=$_GET['qu'];
 if($q>$qu ) header("Location:alert.php?id=$prod_id");
 else
 $sql = "UPDATE `Cart` SET item_quantity=$q WHERE item_id=$prod_id";
 if (mysqli_query($conn, $sql)) {
    header('location:cart.php');
    }
?>