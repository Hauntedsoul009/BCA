<html>
<head>
<title>Login</title>
</head>
<body>
<?php
session_start();
include('Connection/connection.php');
  $servername = "localhost";
  $username = "root";
  $password = "";
  $databasename = "Project";
  
  // CREATE CONNECTION
  $conn = new mysqli($servername,$username, $password, $databasename);
  
  // GET CONNECTION ERRORS
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }
$i=$_POST['userid'];
$p=$_POST['userpassword'];
$query="SELECT *FROM `user` where userid='$i' and userpassword='$p'";
  $result = $conn->query($query);
$s= $result->fetch_assoc();
if(!$s)
  {
   echo "<br>";
   echo '<script type="text/javascript">';
   echo 'alert("Check your email and password")';
   echo '</script>';
   return;
  }
 else
 {
     echo '<script type="text/javascript">
     alert("Successfully logged in")
     </script>';
     header("Location:Home.php?uid=$i");
 }
?>
</body>
</html>