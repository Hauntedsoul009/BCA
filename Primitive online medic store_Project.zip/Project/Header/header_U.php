<!DOCTYPE html>
<html lang="en">
<head>
<title>User Profile</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {font-family: "Lato", sans-serif}
.mySlides {display: none}
</style>
</head>
<!-- Navbar -->
<b><div class="w3-top">
  <b><div class="w3-bar w3-blue w3-card">
    <a class="w3-bar-item w3-button w3-hover-red w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onClick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="#" class="w3-bar-item w3-button w3-hover-red w3-padding-large w3-hide-small">User <i class='fa fa-user-circle' aria-hidden='true'></i></a>
    </div>
    </div>
	 <marquee direction="right" behaviour="alternate">
	 <img src="Images/Dettol.Jpg "style="width:60%">
	<img src="Images/Cetaphil.jpg"style="width:60%">
	<img src="Images/-Easlylax-L.jpg"style="width:60%">
	<img src="Images/prg offer.jpg"style="width:55%">
	<img src="Images/-Moov-CB.jpg"style="width:60%">
	</marquee>
</head>
</html>