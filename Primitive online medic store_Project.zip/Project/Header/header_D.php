<html lang="en">
<head>
<title>Details</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {font-family: "Lato", sans-serif}
.mySlides {display: none}
</style>
</head>
<!-- Navbar -->
<div class="w3-top">
  <b><div class="w3-bar w3-blue w3-card">
    <a class="w3-bar-item w3-button w3-hover-red w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onClick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="Home.php" class="w3-bar-item w3-button w3-hover-red w3-padding-large w3-hide-small">HOME <i class='fa fa-home' aria-hidden='true'></i></a>
    <a href="Category.php?cat_id=2" class="w3-bar-item w3-button w3-hover-red w3-padding-large w3-hide-small">HEALTH CARE DEVICES</a>
	 <div class="w3-dropdown-hover w3-hide-small">
      <button class="w3-padding-large w3-button w3-hover-red" title="More">MEDICINES<i class="fa fa-caret-down"></i></button>     
      <div class="w3-dropdown-content w3-bar-block w3-card-4">
        <a href="Category.php?cat_id=3" class="w3-bar-item w3-button w3-hover-red">Personal Care</a>
        <a href="Category.php?cat_id=4" class="w3-bar-item w3-button w3-hover-red ">Vitamin Supplements</a>
      </div>
    </div>
    <a href="Category.php?cat_id=1" class="w3-bar-item w3-button w3-hover-red w3-padding-large w3-hide-small">COVID ESSENTIALS</a>
      <a href="cart.php" class="w3-padding-large w3-hover-red w3-hide-small w3-right"><i class="fa fa-shopping-cart"></i></a>
  </div>
</div><br><br></b>
<h2 align="Center" style = "color: #4da6ff" ><b>Product Details<i class='fa fa-info-circle' aria-hidden='true'></i></b></h2>
	 <marquee direction="right" behaviour="alternate"scrollamount="20">
	 <img src="Images/Dettol.Jpg "style="width:60%">
	<img src="Images/Cetaphil.jpg"style="width:60%">
	<img src="Images/-Easlylax-L.jpg"style="width:60%">
	<img src="Images/prg offer.jpg"style="width:55%">
	<img src="Images/-Moov-CB.jpg"style="width:60%">
	</marquee>
	