-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 20, 2023 at 07:03 PM
-- Server version: 5.7.34
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `Project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Id` int(25) NOT NULL,
  `Email` varchar(25) NOT NULL,
  `Password` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Id`, `Email`, `Password`) VALUES
(1, 'admin@gmail.com', 'ADMIN');

-- --------------------------------------------------------

--
-- Table structure for table `Cart`
--

CREATE TABLE `Cart` (
  `item_id` int(100) NOT NULL,
  `item_image` varchar(100) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_price` double(10,2) NOT NULL,
  `item_description` varchar(500) NOT NULL,
  `item_quantity` int(100) NOT NULL,
  `itc_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Item_Catagory`
--

CREATE TABLE `Item_Catagory` (
  `item_catagory` varchar(100) NOT NULL,
  `itc_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Item_Catagory`
--

INSERT INTO `Item_Catagory` (`item_catagory`, `itc_id`) VALUES
('Covid_Essentials', 1),
('Health_Care', 2),
('Personal_Care ', 3),
('Vitamin_Supplements', 4);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `item_id` int(100) NOT NULL,
  `item_image` varchar(100) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_price` double(10,2) NOT NULL,
  `item_description` varchar(500) NOT NULL,
  `item_quantity` int(100) NOT NULL,
  `itc_id` int(10) NOT NULL,
  `userid` int(20) NOT NULL,
  `username` varchar(30) NOT NULL,
  `useremail` varchar(50) NOT NULL,
  `userpassword` varchar(8) NOT NULL,
  `useraddress` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`item_id`, `item_image`, `item_name`, `item_price`, `item_description`, `item_quantity`, `itc_id`, `userid`, `username`, `useremail`, `userpassword`, `useraddress`) VALUES
(1, 'dettol_antiseptic_liquid_1_ltr_0_2s.jpg', 'Dettol antiseptic liquid 1 ltr', 364.00, 'The Dettol first aid antiseptic liquid can be used to protect against infection from cuts and scratches, disinfect toys, and sanitize baby wear leaving everything clean and fresh', 2, 1, 1, 'Virat Kohli', 'Vk18@gmail.com', '12345', 'Kottayam Hills'),
(5, 'medisales_ppe_kit_0_0.jpg ', 'Medisales disposable ppe kit', 350.00, 'Men`s and Women`s 70 GSM Disposable Non-Woven Coverall PPE KIT , This comes in the Medical Blue colour.', 3, 1, 1, 'Virat Kohli', 'Vk18@gmail.com', '12345', 'Kottayam Hills'),
(15, 'omron_blood_pressure_cuff_hem_c12.jpg', 'Omron automatic BP monitor', 1889.00, 'These simple wrist-monitoring devices have a compact,portable design that offers extra convenience for those who want to measure blood pressure while travelling or at work ', 1, 2, 1, 'Virat Kohli', 'Vk18@gmail.com', '12345', 'Kottayam Hills'),
(3, 'dettol_instant_hand_sanitizer_original_50_ml.jpg', 'Dettol instant hand sanitizer ', 22.99, 'Your Trusted Dettol offers a new and improved Dettol Hand Sanitizer that is rinse-free and non-sticky.', 2, 1, 2, 'Amal', 'Kt07@gmail.com', '1234', 'Kings Pathamuttom'),
(7, 'wildcraft_hypashield_w95_reusable_outdoor_protection_face_mask_0_0.jpg', 'Wildcraft w95  face mask', 33.50, 'It is an ideal choice against dust, odor, pollen and toxins. It has special filters that have an extended dust holding capacity, ensuring that the mask has a longer shelf life.', 2, 1, 2, 'Amal', 'Kt07@gmail.com', '1234', 'Kings Pathamuttom'),
(2, 'omron_compressor_nebulizer_ne_c101_0.jpg', 'Omron compressor nebulizer', 1899.00, 'Omron NE-C101 makes managing your respiratory health easy', 1, 1, 3, 'Chellam', 'Chellm@gmail.com', '123', 'Parakkulam base station'),
(7, 'wildcraft_hypashield_w95_reusable_outdoor_protection_face_mask_0_0.jpg', 'Wildcraft w95  face mask', 33.50, 'It is an ideal choice against dust, odor, pollen and toxins. It has special filters that have an extended dust holding capacity, ensuring that the mask has a longer shelf life.', 1, 1, 1, 'Virat Kohli', 'Vk18@gmail.com', '12345', 'Kottayam Hills'),
(29, 'inlife_vitamin_c_gummies_orange_flavour_30s.png', 'Inlife Vitamin C  Gummies', 319.00, 'INLIFE vitamin c orange flavored gummies Aids in boosting immunity,Helps in detoxification & cleansing,Prevents acne & protects skin,Supports iron absorption.', 1, 4, 3, 'Chellam', 'Chellm@gmail.com', '123', 'Parakkulam base station');

-- --------------------------------------------------------

--
-- Table structure for table `Products`
--

CREATE TABLE `Products` (
  `item_id` int(100) NOT NULL,
  `item_image` varchar(100) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_price` double(10,2) NOT NULL,
  `item_description` varchar(500) NOT NULL,
  `item_quantity` int(100) NOT NULL,
  `itc_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Products`
--

INSERT INTO `Products` (`item_id`, `item_image`, `item_name`, `item_price`, `item_description`, `item_quantity`, `itc_id`) VALUES
(1, 'dettol_antiseptic_liquid_1_ltr_0_2s.jpg', 'Dettol antiseptic liquid 1 ltr', 364.00, 'The Dettol first aid antiseptic liquid can be used to protect against infection from cuts and scratches, disinfect toys, and sanitize baby wear leaving everything clean and fresh', 45, 1),
(2, 'omron_compressor_nebulizer_ne_c101_0.jpg', 'Omron compressor nebulizer', 1899.00, 'Omron NE-C101 makes managing your respiratory health easy', 50, 1),
(3, 'dettol_instant_hand_sanitizer_original_50_ml.jpg', 'Dettol instant hand sanitizer ', 22.99, 'Your Trusted Dettol offers a new and improved Dettol Hand Sanitizer that is rinse-free and non-sticky.', 100, 1),
(4, 'face_shield_with_elastic_band_0_0.jpg', 'Face shield with elastic band', 24.90, 'Large, clear mylar shield provides maximum visibility. ', 72, 1),
(5, 'medisales_ppe_kit_0_0.jpg ', 'Medisales disposable ppe kit', 350.00, 'Men`s and Women`s 70 GSM Disposable Non-Woven Coverall PPE KIT , This comes in the Medical Blue colour.', 55, 1),
(6, 'romsons_respirometer_0.jpg', 'Romsons respirometer', 212.00, 'Men`s and Women`s 70 GSM Disposable Non-Woven Coverall PPE KIT , This comes in the Medical Blue colour.', 107, 1),
(7, 'wildcraft_hypashield_w95_reusable_outdoor_protection_face_mask_0_0.jpg', 'Wildcraft w95  face mask', 33.50, 'It is an ideal choice against dust, odor, pollen and toxins. It has special filters that have an extended dust holding capacity, ensuring that the mask has a longer shelf life.', 67, 1),
(8, 'wonder_vaporizer_steam_inhaler_0_0.jpg', ' Vaporizer steam inhaler', 221.99, 'It is an ideal choice against dust, odor, pollen and toxins. ', 40, 1),
(9, 'fingertip_pulse_oximeter_mi303_0_0.jpg', 'Fingertip pulse oximeter', 152.00, '0ximeter is quick and easiest way to monitor blood  oxygen level and heart rate', 200, 2),
(10, 'sahyog_wellness_digital_thermometer_0_0.jpg', 'Wellness digital thermometer', 220.00, 'the Topnotch digital thermometer is and efficient device to measure body temperature to determine a fever', 100, 2),
(11, 'omron_thermometer_pencil_type_mc_246_c1.jpg', 'Omron thermometer', 249.00, 'Omron digital thermometer offers a safe accurate and quick temperature reading ', 50, 2),
(12, 'accu_check_guide_wireless_glucometer_kit_.jpg', 'accu check glucometer', 899.00, 'Accu-Check Active wireless Glucometer kit is a machine that is used together with Accu-check active  strips to measure the glucose content int the blood ', 50, 2),
(13, 'arm.jpg', 'Tynor Elbow Support ', 190.00, 'Get the best support for your orthopedic issues with the tynor elbow support  that is specially designed to give your elbow a firm compression ', 20, 2),
(14, 'sahyog_wellness_hot_water_bottle_bag_red.jpg', 'Wellness hot water bottle ', 370.00, 'Wellness hot water bottle are made with high quality and odourless rubber and it helps in providing relief from all kinds of muscular pain', 50, 2),
(15, 'omron_blood_pressure_cuff_hem_c12.jpg', 'Omron automatic BP monitor', 1889.00, 'These simple wrist-monitoring devices have a compact,portable design that offers extra convenience for those who want to measure blood pressure while travelling or at work ', 100, 2),
(16, 'dr_odin_steam_vaporizer_od_03_0_0.jpg', 'Dr Odin Steam Vaporizer', 199.00, 'use tap water and pour it up to the level  mark or according to your requirement connect the required attachment on top plug in and switch it on after use switch it off and take out the plug ', 30, 2),
(17, 'body_cream.jpg', 'Nivea Moisturizing Body Cream', 180.00, 'About this item:\r\n\r\nLong Lasting moisturisation: The NIVEA Deep Moisture Serum formula gives you moisturised skin for up to 48 hours.\r\nNatural Ingredients: Almond oil and vitamin E nourish & repair the skin from deep within.\r\nIdeal for daily use: Apply daily for intensive moisture care & to reduce roughness of dry skin.\r\nSkin Type: It effectively transforms very dry skin to healthy, smooth skin.; Skin compatibility dermatologically approved.\r\nTarget Gender: Unisex', 100, 3),
(18, 'body_lotion.jpg', 'Nivea Nourishing Body Lotion', 249.00, 'About this item:\r\n\r\nNIVEA body lotion, nourishing body milk, for very dry skin.\r\nLasting moisturisation : The deep moisture serum formula gives you moisturized skin for up to 48 hours.\r\nReduces roughness of skin.; The nourishing almond oil repairs very dry skin.\r\nSkin compatibility dermatologically approved.\r\nTarget Gender: Unisex', 50, 3),
(19, 'facewash.jpg', 'Himalaya Neem Face Wash', 78.00, 'Himalaya Herbals Purifying Neem Facial wash is a facial cleansing gel for daily use that cleanses the skin by removing excess oil and impurities without dehydrating it, it uses a special formula so that your skin is clean and radiant. Known for its purifying and antibacterial properties, Neem, in combination with Turmeric, helps control impurities and blackheads, leaving skin soft, clean and healthy looking. Moisten the face and massage it avoiding the eye area. Rinse and gently pat dry. ', 72, 3),
(20, 'hand_wash.jpg', 'Dettol  Liquid Handwash', 120.00, 'Germ Protection: Protects from 100 illness causing germs. Recommended by Indian Medical Association (IMA).Pump-handle design for convenient use.', 55, 3),
(21, 'shampoo.jpg', 'Anti-dandruff shampoo', 90.00, '1 in 2 people in the world have suffered from dandruff at some point in their lives. Make sure you’ve got a way to fight back with the Head & Shoulders anti-dandruff shampoo. Every shampoo is specially formulated to deal with both the symptoms and cause of dandruff. This is made possible due to zinc pyrithione, which research has shown to be among the most effective ways of dealing with dandruff', 107, 3),
(22, 'soap.jpg', 'Lifebuoy Soap (silver shield)', 25.00, 'Lifebuoy Care soap bar is specially formulated to give both germ protection and care. It contains the goodness of milk cream and gives your skin a soft and smooth feel. Lifebuoy Care soaps have advanced Silver Shield Formula gives 100% stronger protection*. Our skin is the first line of defense from the outside world', 67, 3),
(23, 'vaseline.jpg', 'Vaseline Pure skin jelly', 49.00, 'Vaseline Petroleum jelly is hugely versatile, and it is used all over the world to protect and heal dry skin, from dry, cracked hands to hard skin on heels, as well as for beauty purposes, like softening the lips or highlighting the cheekbones!. ', 40, 3),
(24, 'dettol1.jpg', 'Dettol Antiseptic Liquid', 55.00, 'Your Trusted Dettol offers a new and improved Dettol Antiseptic Liquid.\r\nANTISEPTIC LIQUID: Protects from 100 illness causing germs\r\nDISINFECTANT LIQUID: Antiseptic Liquid used to disinfect household items and surfaces\r\nMULTIPURPOSE CLEANER: Great for everyday personal and home hygiene\r\nUSAGE: Ideal to be used for First Aid, cleaning cuts and wounds.', 100, 3),
(25, 'Inlife Vitamin E Oil.PNG', 'Inlife Vitamin E Wheat Germ Oil', 539.00, 'Inlife Vitamin E + Wheat Germ Oil Capsules are a combination of Vitamin C and Vitamin E, which are a useful as an antioxidant.\r\nHelps to cure excess blood flow & menstrual pain, muscles cramps.\r\nProtects the skin from harmful effects of UV rays.\r\nBoosts up strength and improves physical performance in the elderly.\r\nCures eye irritation.\r\nReduces the chances of memory loss.\r\nPrevents onset of Schizophrenia.\r\n ▪Usage: Take 1capsules daily', 100, 4),
(26, 'Truuth Multivitamin Multimineral Capsules 60s.png', 'Truuth Multivitamin Capsules', 145.00, 'TRUUTH Multivitamin Capsules Supports Energy Metabolism,Supports Immune Health,Supports Healthy Bone and Muscle Function,Gluten Free,Non-GMO', 300, 4),
(27, 'truuth_omega_3_vegan_capsules.png ', 'Truuth Omega-3 Capsules', 559.00, 'Omega-3 is a great way to maintain healthy levels of EPA and DHA. Each serving supports heart and brain health, cognition and healthy immune function.  Packed with naturally occurring Omega-3, EPA and DHA, Fish Oil contains beneficial fatty acids that may help reduce the risk of coronary heart disease.** Our superior formula provides you 300 mg Omega-3 fatty acids per Capsule. Purified to eliminate mercury and other heavy metals.', 550, 4),
(28, 'smart_greens_plant_based_vitamin_b_complex_capsule.png', ' Vitamin B Complex Capsules', 659.00, 'Vitamins are important building blocks of the body and help keep you in good health.This product is a combination of B vitamins used to treat or prevent vitamin deficiency due to poor diet, certain illnesses, alcoholism, or during pregnancy. Our product contains vitamin B6, vitamin B12, folic acid, and pantothenic acid.Thisproduct is completely plant based and contains no artificial ingredients or flavors.', 600, 4),
(29, 'inlife_vitamin_c_gummies_orange_flavour_30s.png', 'Inlife Vitamin C  Gummies', 319.00, 'INLIFE vitamin c orange flavored gummies Aids in boosting immunity,Helps in detoxification & cleansing,Prevents acne & protects skin,Supports iron absorption.', 450, 4),
(30, 'healthvit_biotino_z_biotin_with_zinc_capsules_60s.png', 'Healthvit Biotin Zinc Capsules', 225.00, 'HEALTHVIT Biotino-Z Capsules contains Biotin and Zinc as its active ingredients. It also contains Magnesium Stearate, Anhydrous Lactulose, and Colloidal Silicon Dioxide as other ingredients. HealthVit Biotino- Z Capsule is scientifically formulated nutritional support that significantly increases hair growth. \r\n\r\n▪use/Dosage:\r\n- One capsule one time daily or as directed by the physician', 320, 4),
(31, 'vitawin vitamin d capsules 60s.png', 'Vitawin Vitamin D Capsules', 359.00, 'VITAWIN Vitamin D Vegetarian Capsuleis a herbal formulation that can help in increasing muscle and bone strength.', 400, 4),
(32, 'bio.png', 'Biotin Vitamin B12 Gummies', 899.00, 'BIOTIN B12 Gummies are formulated with of pure easily absorbable Biotin and b12 that is rich in fatty acids & powerful antioxidants that give your hair the right nutrition. ', 350, 4);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `usermail` varchar(50) NOT NULL,
  `userpassword` varchar(50) NOT NULL,
  `useraddress` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `username`, `usermail`, `userpassword`, `useraddress`) VALUES
(1, 'Virat Kohli', 'Vk18@gmail.com', '12345', 'Kottayam Hills'),
(2, 'Amal', 'Kt07@gmail.com', '1234', 'Kings Pathamuttom'),
(3, 'Chellam', 'Chellm@gmail.com', '123', 'Parakkulam base station'),
(4, 'Driyf', 'Jyryry@gmail.com ', '1', 'Qwerty');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `Cart`
--
ALTER TABLE `Cart`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `Item_Catagory`
--
ALTER TABLE `Item_Catagory`
  ADD PRIMARY KEY (`itc_id`);

--
-- Indexes for table `Products`
--
ALTER TABLE `Products`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Cart`
--
ALTER TABLE `Cart`
  MODIFY `item_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `Products`
--
ALTER TABLE `Products`
  MODIFY `item_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
