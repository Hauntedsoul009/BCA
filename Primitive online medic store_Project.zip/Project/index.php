<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login/register</title>
	<style>
    *{
    margin: 0;
    padding: 0;
    font-family: sans-serif;
    box-sizing: border-box;

}
.rest{
    height: 100%;
    width: 100%;
    background-image: linear-gradient(rgba(0,0,0,0.4),
    rgba(0,0,0,0.4)),url(Images/loginbg1.jpeg);
    background-position: center;
    background-size: cover;
    position: absolute;
}

.form-box{
    width: 380px;
    height: 500px;
    position: relative;
    margin: 6% auto;
    background: #fff;
    padding: 5px;
    border-radius: 50px;
    overflow: hidden;
}
.button-box{
    width: 220px;
    margin: 35px auto;
    position: relative;
    box-shadow: 0 0 20px 9px #ff61241f;
    border-radius: 30px;
}
.toggle-btn{
    padding: 10px 30px;
    cursor: pointer;
    background: transparent;
    border: 0;
    outline: none;
    position: relative;
}

#btn{
    top:0;
    left: 0;
    position: absolute;
    width: 110px;
    height: 100%;
    background: linear-gradient(to right,teal,yellow);
    border-radius: 30px;
    transition: 0.5s;
}

.social-icon{
    margin: 30px auto;
    text-align: center;
}

.login-icon img{
    width: 30px;
    margin: 0 12px;
    box-shadow: 0 7px 0 #7f7f7f3d;
    cursor: pointer;
    border-radius: 50%;
}

.input-group{
    top: 180px;
    position: absolute;
    width: 280px;
    transition: .5s;
}


.input-field{
    width: 100%;
    padding: 10px 0;
    margin: 5px 0;
    border-left: 0;
    border-top: 0;
    border-right: 0;
    border-bottom: 1px solid #999;
    outline: none;
    background: transparent;
}

.submit-btn{
    width: 85%;
    padding: 10px 30px;
    cursor: pointer;
    display: block;
    margin: auto;
    background:linear-gradient(to right,yellow,teal);
    border: 0;
    outline: none;
    border-radius: 30px;
}
.check-box{
    margin: 30px 10px 30px 0;
}
span{
    color: #777;
    font-size: 12px;
    bottom: 68px;
    position: absolute;
}
#login{
    left: 50px;
}

#register{
    left: 450px;
}
</style>
</head>
<body>
    <div class="rest">
        <div class="form-box">
            <div class="button-box">
                <div id="btn"></div>
                <button type="button" class="toggle-btn" onClick="login()">Log In</button>
                <button type="button" class="toggle-btn" onClick="register()">Register</button>
            </div> 
			<div class="login-icon">
			<center>
			<img src="Images/loginicon.png">
			</center>
			 </div>
            <form id="login" class="input-group" action="logincheck.php" method="post">
                <input type="text" class="input-field" name="userid" placeholder="Enter your user-id" required>
                <input type="password" class="input-field" name="userpassword" placeholder="Enter Password" required>
                <input type="checkbox" class="check-box"><span>Remember Password</span>
                <button type="submit" class="submit-btn">Log In</button>
            </form>


            <form id="register" class="input-group" action="loginenter.php" method="post">
                <input type="text" class="input-field" name="userid" placeholder="Enter user-id" required>
                <input type="text" class="input-field" name="username" placeholder="Enter your name" required>
				<input type="text" class="input-field" name="usermail" placeholder="Enter your email" required>
                <input type="password" class="input-field" name="userpassword" placeholder="Enter Password" required>
	            <input type="text" class="input-field" name="useraddress" placeholder="Enter your Address"required>	
               
                <button type="submit" class="submit-btn">Register</button>
				</form>
        </div>
        
    </div>
<script>
    var x=document.getElementById("login");
    var y=document.getElementById("register");
    var z=document.getElementById("btn");

    function register(){
        x.style.left="-400px";
        y.style.left="50px";
        z.style.left="110px";


    }


    function login(){
        x.style.left="50px";
        y.style.left="450px";
        z.style.left="0px";
    }


</script>
</body>
</html>