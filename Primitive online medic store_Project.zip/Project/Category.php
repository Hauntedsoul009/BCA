<?php
include('Header/header.php');
include('Connection/connection.php');

if(isset($_GET['cat_id'])){
 	$c_id=$_GET['cat_id'];
  // SQL QUERY
  $query = "SELECT * FROM `Products` WHERE itc_id=$c_id";
  // FETCHING DATA FROM DATABASE
  $result = $conn->query($query);
  
    if ($result->num_rows > 0) 
    {
        // OUTPUT DATA OF EACH ROW
        while($row = $result->fetch_assoc())
{
             $pro_id=$row['item_id'];
            
             $pro_nam=$row['item_name'];
             $pro_pri=$row['item_price'];
             $pro_des=$row['item_description'];
             $pro_img=$row['item_image'];
             $it_id=$row['itc_id'];
              $pro_q=$row['item_quantity'];
            echo"<div class='row'>
  <div class='column'>
  <div class='card'>
    <img src='Images/$pro_img 'style='width:100%'>
  <h6><b>$pro_nam</b></h6>
  <p class='price'>₹$pro_pri</p>
   <p class='Quantity:'><b>In Stock: </b>$pro_q</p>
    <p><a href='Details.php?product_id=$pro_id' class='w3-button w3-hover-red w3-blue'>Details <i class='fa fa-info-circle' aria-hidden='true'></i></button></a></p>
    </div>
  </div>";
             }
      }    
} 
             ?>	
<html>
<head>
<link rel='stylesheet' href='Stylesheets/card.css' type='text/css' media='all' />
</head>
</html>