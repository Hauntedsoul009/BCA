<?php
session_start();
include('Connection/connection.php');
include('Header/header_D.php');
if(isset($_GET['id'])){
 	$prod_id=$_GET['id'];
 }
 if(isset($_GET['qu'])){
 	$pro_q=$_GET['qu'];
 }
$sql = "INSERT  INTO `Cart` SELECT * FROM `Products`  WHERE item_id=$prod_id";
if (mysqli_query($conn, $sql)) {
    echo "<div class='column'>
  <div class='card'>
  	   <p class='Quantity:'><b>In Stock: </b>$pro_q</p>
<form action='quant_alt.php?id=$prod_id' method='get'>
     Quantity Required:<input type='text' name='quant'><br>
      <input type='hidden' name='id' Value=$prod_id><br>
      	 <input type='hidden' name='qu' Value=$pro_q><br>
   <input type='Submit' name='submit'  class='w3-button w3-blue' ></form>
</div>
    </div>";
} else {
     echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
//header('location:cart.php');
mysqli_close($conn);
?>
<html>
<head>
<link rel='stylesheet' href='Stylesheets/card.css' type='text/css' media='all' />
</head>
</html>
</body>
</html>