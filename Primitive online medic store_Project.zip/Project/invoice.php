<!DOCTYPE html>
	<?php
	session_start();
include('Header/header_B.php');
include('Connection/connection.php');
$servername = "localhost";
  $username = "root";
  $password = "";
  $databasename = "Project";
  
  // CREATE CONNECTION
  $conn = new mysqli($servername,$username, $password, $databasename);
  
  // GET CONNECTION ERRORS
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }
if(isset($_GET['uid'])){
 	$uid=$_GET['uid'];
 }
 if(isset($_GET['tp'])){
 	$tp=$_GET['tp'];
 }
 $na=$_SESSION["na"]; 
 $ad=$_SESSION["ad"];
 	  // SQL QUERY
  $query = "SELECT * FROM `Cart` JOIN `user` WHERE userid=$uid";
  // FETCHING DATA FROM DATABASE
  $result = $conn->query($query);
//  $mysqli->close();
  ?>
<html lang="en">
<head>
<meta charset="utf-8">" <title>PHARMA_INVOICE</title>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<script src='https://code.jquery.com/jquery-1.10.2.min.js'></script>
<link href='https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/css/bootstrap.min.css' rel='stylesheet'>
<script src='https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/js/bootstrap.bundle.min.js'></script>
</head>
<body>
<div class='container'>
<div class='row gutters'>
<div class='col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12'>
<div class='card'>
<div class='card-body p-0'>
<div class='invoice-container'>
<div class='invoice-header'>

<div class='row gutters'>
<div class='col-xl-12 col-lg-12 col-md-12 col-sm-12'>

</a>
</div>
</div>
</div>


<div class='row gutters' >
<div class='col-xl-6 col-lg-6 col-md-6 col-sm-6'>
<a href='home.php' class='invoice-logo'>
PHARMA
</a>
</div>
<div class='col-lg-6 col-md-6 col-sm-6'>
<address class='text-right'>
<?php echo "*take a screenshot of this page for future references    ";?>
</address>
</div>
</div>
<div class='row gutters'>
<div class='col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12'>
<div class='invoice-details'>
<address>
<?php echo"$na <br>
$ad";
	?>
</address>

</div>
</div>
<div class='col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12'>
<div class='invoice-details'>
<div class='invoice-num'>
<div><?php echo date("d/m/Y") . "<br>";?></div>
</div>
</div>
</div>
</div>

</div>
<div class='invoice-body'>

<div class='row gutters'>
<div class='col-lg-12 col-md-12 col-sm-12'>
<div class='table-responsive'>
<table class='table custom-table m-0' >
<thead>
	<tr>
<th>Items</th>
<th>Product ID</th>
<th>Quantity</th>
<th>Price/Item</th>
</tr>
</thead>
<?php
        while($rows=$result->fetch_assoc())
{
	?>
<tbody>
<tr>
<td>
<?php echo $rows['item_name'];?>
<p class='m-0 text-muted'></p></td>
<td><?php echo $rows['item_id'];?></td>
<td><?php echo $rows['item_quantity'];?></td>
<td>Rs.<?php echo $rows['item_price'];?></td>
</tr>
<?php
}
?>
<tr>
<td>&nbsp;</td><td colspan='2'><p>
Subtotal<br>
Shipping &amp; Handling<br>
Tax<br></p>
<h5 class='text-success'><strong>Grand Total</strong></h5>
</td>
<td>
<p>
<br>
<br>Rs.50<?php $f=50?><br>
</p>
<?php $gt=$tp+$f?>
<h5 class='text-success'><strong>Rs.<?php echo"$gt" ?></strong></h5>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
</div>
<div class="invoice-footer">
</b>Cash on delivery only.Thankyou!!🙂</b>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<script type="text/javascript">
</script>
</body>
<link rel='stylesheet' href='' type='text/css' media='all' />
<br>
<?php echo"
 <p align='center' ><a href='addtorder.php?uid=$uid&tp=$tp'class='w3-button w3-hover-red w3-blue'>Confirm<i class='fa fa-check'></i></a></p>";
 ?>
</html>